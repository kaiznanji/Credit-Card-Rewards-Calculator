from . import (
    rewards,
    rules
)

routers = [
    rewards.router,
    rules.router
]